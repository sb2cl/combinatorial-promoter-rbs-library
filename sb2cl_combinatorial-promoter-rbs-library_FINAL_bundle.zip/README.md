# pIAKA combinatorial promoter–RBS library

This repository contains:
- Annotated GenBank files (`genbank/`)
- SBOL3 design files with *formal combinatorial derivations* split by backbone (`sbol/`)
  - `library_pSC101.sbol3.xml`
  - `library_pGreen.sbol3.xml`

## SBOL3 base URI
The SBOL3 files were generated with a placeholder base namespace:

    https://github.com/sb2cl/combinatorial-promoter-rbs-library/

Before publishing, you may wish to replace this with your final repository namespace
(e.g., your GitHub Pages URL or another stable URI). A simple global search/replace
is sufficient.

## Suggested citation
When you create a Zenodo release, cite the Zenodo DOI here and in the manuscript.

## Reproducibility

### Validate the library
```bash
python scripts/validate_library.py --table metadata/library_table_from_paper.csv --genbank-dir genbank
```

### Regenerate SBOL3 files
```bash
python scripts/make_sbol_library.py --base-uri "https://<your-namespace>/" --table metadata/library_table_from_paper.csv --genbank-dir genbank --outdir sbol
```

The GitHub Action `.github/workflows/validate-library.yml` runs these checks automatically on every push/PR.
